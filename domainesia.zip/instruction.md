File Sql:

1. Import mysql file -> tests.sql
2. There is table 'people'


End Point Example:
127.0.0.1/{root_folder}/restapi.php/{table_name}/{id}


A. Method 'GET'
    1. Fetch data = 127.0.0.1/{root_folder}/restapi.php/people
    2. Get data by id = 127.0.0.1/{root_folder}/restapi.php/people/1
