Saya memilih jawaban c
    App in CodeIgniter to Laravel-based.
    
Jawaban : Jika ingin migrasi saya akan menggunakan per-components transition atau memulai dari component satu per satu
Alasan: 
A. Karena apabila aplikasi sudah komplek atau besar lingkup nya akan susah melakukan overlapping tanpa kendala, biasanya kebanyakan harus 
    menyesuaikan dengan code logic dari CI ke laravel misalnya.
B. Dapat memulai dari penyesuaian controller, view dan model satu persatu dengan teliti
C. Dapat lebih fokus pengembangan dan penyesuaian bahasa dan struktur kodingnya
D. Dapat memilih migrasi misal nya dari asset, library, helper atau database dan seterusnya
        





