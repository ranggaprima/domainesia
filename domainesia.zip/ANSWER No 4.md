My Cover Letter

I am excited applying for backend developer. With backend technologies there is always something new to discover.
Designing the backend code that truly helpful to the user is my goal. And I am delighted by the opportunity to apply my knowledge.
During my previous role of my backend experiences is provided the end user end point and implementing third party.
After Test driven passed the code then implemented in the real system.

My goal is to continually increase my programming skills in order to present better solutions to my employers and their clients. 
And I enjoy that I can develop my backend experience especially in php with modern technologies
And how my experince can contribute to development team
