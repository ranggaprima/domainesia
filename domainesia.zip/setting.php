;<?php return; ?>
[SQL]
HOST = 127.0.0.1
USER = root
PASS =
DB = tests
